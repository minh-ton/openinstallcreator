#!/bin/sh

#  ElCapitan.sh
#  CreateInstallMedia
#
#  Created by Ford on 3/14/20.
#  Copyright © 2020 MinhTon. All rights reserved.

echo "/Install\ macOS\ El\ Capitan.app"
