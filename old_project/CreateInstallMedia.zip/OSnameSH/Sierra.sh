#!/bin/sh

#  Sierra.sh
#  CreateInstallMedia
#
#  Created by Ford on 3/14/20.
#  Copyright © 2020 MinhTon. All rights reserved.

echo "/Install\ macOS\ Sierra.app"
